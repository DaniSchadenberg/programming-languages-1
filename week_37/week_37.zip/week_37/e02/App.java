package Excercise.week_37.e02;

class App {
    public static void main(String[] args) {
        int age = 26;
        double temprature = 22.5;
        char inital = 'D';

        System.out.println(age);
        System.out.println(temprature);
        System.out.println(inital);
    }
}
package Excercise.week_37.e03;

class App {
    public static void main(String[] args) {
        int a = 5;
        int b = 20;
        int sum = a + b;
        System.out.println(sum);
    }
}
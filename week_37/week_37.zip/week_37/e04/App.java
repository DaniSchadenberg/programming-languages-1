package Excercise.week_37.e04;

class App {
    public static void main(String[] args) {
        int num = 5;
        double decimal = 4.25;
        double sum = num + decimal;
        System.out.println(sum);
    }
}
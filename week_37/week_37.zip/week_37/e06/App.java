package Excercise.week_37.e06;

class App {
    public static void main(String[] args) {
        boolean isJavaFun = true;
        boolean isFishTasty = false;
        System.out.println(isJavaFun && isFishTasty);
        System.out.println(isJavaFun || isFishTasty);
        System.out.println(isJavaFun != isFishTasty);
    }
}